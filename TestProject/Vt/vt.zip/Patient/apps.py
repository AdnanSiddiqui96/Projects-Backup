from django.apps import AppConfig


class PatientConfig(AppConfig):
    name = 'Patient'
