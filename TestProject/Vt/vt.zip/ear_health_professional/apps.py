from django.apps import AppConfig


class EarHealthProfessionalConfig(AppConfig):
    name = 'ear_health_professional'
