from django.apps import AppConfig


class EarhealthwebConfig(AppConfig):
    name = 'earhealthweb'
